"""Replay mismatching controls with imports from the frozen f8e0b00 checkout."""
import os
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
import gzip
import json
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory
import shutil

import kaiser

work = Path.cwd()
base = work / "artifacts/experiment/dev"
old = Path(kaiser.__file__).resolve().parents[3]


def run(item):
    path, config = item
    current = json.load(gzip.open(path))
    seed = current["seed"]
    index = int(seed.rsplit("_", 1)[1])
    with TemporaryDirectory() as temp:
        out = Path(temp)
        shutil.copyfile(config, out / "kaiser_config.json")
        kaiser.ROOT = work  # supply only the local pinned NativeSession runtime links
        kaiser.episode((base/"arm4/policy/policy.json", out, [index, seed, current["act_list"]], False, "treatment"))
        frozen = json.load(gzip.open(out / path.name))
    def evidence(r):
        return [(i, row["oracle"], row["difference"], row["replay"]) for i,row in r.get("errors", [])]
    assert all(current[k] == frozen[k] for k in ("native","commands","floor","act","steps","late_fights"))
    assert evidence(current) == evidence(frozen)
    return {"seed":seed, "commands":current["commands"], "native":current["native"],
            "mismatches":len(evidence(current)), "all_error_boards_and_predictions_identical":True}


if __name__ == "__main__":
    import sts2rl
    assert os.path.commonpath([old, Path(sts2rl.__file__).resolve()]) == str(old)
    assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=old,text=True).startswith("f8e0b00")
    subprocess.run(["git","diff","--exit-code","f8e0b00","--","src","docs/combat-search-v2/probes/kaiser.py"],cwd=old,check=True)
    paths=[p for p in (base/"v63").glob("*.gz") if json.load(gzip.open(p))["mismatches"]]
    with ProcessPoolExecutor(12) as pool:
        rows=list(pool.map(run,[(p,p.with_name("kaiser_config.json")) for p in paths]))
    print(rows)
    (base.parent/"frozen-mismatches.json").write_text(json.dumps(rows))
