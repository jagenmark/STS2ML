"""Replay Control from the original v6.5 checkout and compare physical outcomes."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import hashlib,json,gzip,os,subprocess,runpy
from v64 import ROOT,episode

def play(args):
    folder,bundle,row=args
    episode(folder,bundle,row)
    return row[1]

if __name__ == "__main__":
    folder=Path(os.environ["TEMP"])/"csv11-control-reference"
    folder.mkdir(exist_ok=True)
    assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip()=="8c27ce5ddf5348f88b1cedb3c3cd5b24bd5c40b1"
    build=runpy.run_path(str(ROOT/"scripts/build-batch1-challengers.py"))["build_batch1_bundle"]
    target=folder/"bundle"
    bundle=target/"policy/policy.json" if target.exists() else build(ROOT/"releases/silent-a10-mecha-knight/challenger/policy.json",target,profile="trap_cleanup_v65")
    manifest=json.loads((Path(os.environ["CSV11_CANDIDATE"])/"manifest.json").read_bytes())
    assert hashlib.sha256(bundle.read_bytes()).hexdigest()==manifest["bundles"]["control"]
    jobs=[(folder,bundle,t) for t in manifest["cohort"] if not (folder/(t[1]+".json.gz")).is_file()]
    with ProcessPoolExecutor(12) as executor:
        list(executor.map(play,jobs))
    compared={}
    for _,seed,_ in manifest["cohort"]:
        def load(path):return json.loads(gzip.decompress(path.read_bytes()))
        ref=load(folder/(seed+".json.gz"))
        candidate=load(Path(os.environ["CSV11_CANDIDATE"])/"control"/(seed+".json.gz"))
        for k in ref:
            if k in ("latency_us","mismatches"):continue
            assert ref[k]==candidate[k],(seed,k)
        assert [m["oracle"] for m in ref["mismatches"]]==[m["oracle"] for m in candidate["mismatches"]]
        compared[seed]=ref["commands"]
    (Path(os.environ["TEMP"])/"csv11-compat/control-replay.json").write_text(json.dumps(compared,indent=2))
    print(len(compared),"exact base command transcripts and deterministic episode results")
