"""Reject reserved panel names when running the pinned historical regressions."""
from sts2rl.native import NativeSession

original = NativeSession.reset

def reset(self, seed, *args, **kwargs):
    if seed.startswith(("FINAL768B", "POOLED896", "VAL256", "SEEDED128", "TRUE_SEEDED", "REP512")):
        raise AssertionError("Reserved native lobby " + seed)
    return original(self, seed, *args, **kwargs)

NativeSession.reset = reset
