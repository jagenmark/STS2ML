from concurrent.futures import ProcessPoolExecutor
from hashlib import sha256
import gzip,json,os
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from audit384 import collect,ROOT
from sts2rl.native import NativeSession,digest
from collections import Counter
from contextlib import ExitStack
out=ROOT/"artifacts/autopsy"
seeds=["AUDIT384_DEFAULT_0161","AUDIT384_SEEDED_0093","AUDIT384_SEEDED_0139","AUDIT384_SEEDED_0144"]
def replay(job):
    seed,mode_on=job
    mode=seed.split("_")[1].lower()
    trace=[]
    orig=NativeSession.step
    def step(host,act):
        trace.append((act.snapshot,act.command()))
        return orig(host,act)
    with TemporaryDirectory(dir=ROOT/"artifacts") as tmp:
        # Use the verified static forecast resources, avoid modifying final receipts.
        d=Path(tmp)
        import shutil
        shutil.copytree(out/"rules",d/"rules")
        with patch.object(NativeSession,"step",step):
            label,status,error,native=collect((d,out/"arm4/policy/policy.json",[int(seed[-4:]),seed,mode],mode_on))
        assert label==seed and status=="complete" and not error
    return seed,mode_on,trace,native
def paths(a,b,loc=""):
    if a==b:return []
    if isinstance(a,dict) and isinstance(b,dict):
        return [p for k in sorted(a.keys()|b.keys()) for p in paths(a.get(k),b.get(k),loc+"/"+k)]
    if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
        return [p for l,r in zip(a,b) for p in paths(l,r,loc+"/[]")]
    return [loc]
def compare_hosts(pair):
    seed,commands=pair
    mode=seed.split("_")[1].lower()
    diffs=Counter()
    with TemporaryDirectory(dir=ROOT/"artifacts") as tmp,ExitStack() as st:
        a,b=[st.enter_context(NativeSession(ROOT,Path(tmp)/tag,host_path=os.environ["CSV2DEV_HOST"],act_list=mode)) for tag in ("a","b")]
        s=a.reset(seed);t=b.reset(seed)
        for cmd in commands:
            if digest(s)!=digest(t):
                diffs.update(set(paths(s,t)))
            s=a._request(cmd);t=b._request(cmd)
        diffs.update(set(paths(s,t)))
    return seed,dict(diffs)
if __name__=="__main__":
    result={}
    with ProcessPoolExecutor(12) as p:
        traces=list(p.map(replay,[(seed,t) for seed in seeds for t in (False,True)]))
        by={(s,t):tr for s,t,tr,native in traces}
        commands={}
        for seed in seeds:
            x,y=by[seed,False],by[seed,True]
            xc=[c for _,c in x];yc=[c for _,c in y]
            assert xc==yc,seed
            cmds=digest(xc)
            commands[seed]=xc
            result[seed]=dict(steps=len(x),commands_sha256=cmds,plain_commands_sha256=cmds,
                              telemetry_commands_sha256=digest(yc),different_snapshots=sum(a!=b for (a,_),(b,_) in zip(x,y)))
        for seed,delta in p.map(compare_hosts,commands.items()):
            result[seed]["independent_identical_command_replay_fields"]=delta
    Path("artifacts/trace-parity.json").write_text(json.dumps(result))
    print(result)
