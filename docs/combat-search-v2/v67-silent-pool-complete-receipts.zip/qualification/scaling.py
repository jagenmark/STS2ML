from dataclasses import replace
from pathlib import Path
from statistics import median
from tempfile import TemporaryDirectory
from time import perf_counter
from timeit import Timer
import json,os
from test_silent_cards_v67_native import Oracle, NativeSession, HOST, ROOT, start
from sts2rl.combat_search_v2.state import project,Move,Variant
from sts2rl.combat_search_v2.transitions import advance
from sts2rl.combat_search_v2.value import _power_value
with TemporaryDirectory() as d, NativeSession(ROOT,Path(d)/"game",host_path=HOST) as g:
 o=Oracle(g)
 start(o,"EXPERTISE",["EXPERTISE"])
 root=project(o.public,silent_cards_v67=True).state
 c=Variant("DEFLECT","Skill",0,"Self")
 discard=Variant("ACROBATICS","Skill",1,"Self")
 out={}
 for n in (32,128,512):
  s=replace(root,draw=(c,)*n)
  assert len(advance(s,Move("play_card",0)).hand)==2
  scored=replace(root,powers=(("MASTER_PLANNER",1),),draw=(c,discard)*(n//2))
  row={}
  for name,fn in [("expertise",lambda:advance(s,Move("play_card",0))),("planner_value",lambda:_power_value(scored))]:
   fn()
   row[name]=round(1e6*median(Timer(fn,timer=perf_counter).repeat(repeat=7,number=256))/256,2)
  out[n]=row
 dest=Path(os.environ['TEMP'])/'csv12-compat-decf295/scaling.json'
 dest.write_text(json.dumps(dict(metric="median elapsed microseconds per call",repeats=7,calls_per_repeat=256,pile_sizes=out),indent=2))
 print(out)
