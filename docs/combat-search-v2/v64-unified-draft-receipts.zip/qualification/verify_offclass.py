"""Check transcript equivalence on all unified starts that offered one of the off-class cards."""
from concurrent.futures import ProcessPoolExecutor
import gzip,json
from v64 import ARMS,ROOT,cohort,episode
out=ROOT/'artifacts/v64'
changed={'RIGHT_HAND_HAND','MULTI_CAST','HEAVENLY_DRILL'}
def affected(r):
    return sorted({c[0] for e in r['offers'] for group in (e[3] if e[2]=='bundle_select' else [e[3]]) for c in group} & changed)
def verify(job):
    arm,triple=job
    archive=out/'dev'/arm
    r=json.load(gzip.open(archive/(triple[1]+'.json.gz')))
    names=affected(r)
    if not names:return arm,None
    check=out/'offclass'/arm
    episode(check, archive/'policy/policy.json',triple)
    rerun=json.load(gzip.open(check/(triple[1]+'.json.gz')))
    fields=['commands','offers','act','floor','steps','status','win','boss_fights','native','deck_size','late_fights']
    return arm,dict(seed=triple[1],cards=names,identical=all(r[k]==rerun[k] for k in fields),commands=rerun['commands'])
if __name__=='__main__':
    arms=ARMS[1:]
    for arm in arms:(out/'offclass'/arm).mkdir(parents=True,exist_ok=True)
    with ProcessPoolExecutor(12) as pool:
        rows=list(pool.map(verify,[(a,t) for a in arms for t in cohort()]))
    proof={arm:[v for a,v in rows if a==arm and v] for arm in arms}
    print(proof,flush=True)
    (out/'offclass-proof.json').write_text(json.dumps(proof,indent=2))
    assert all(r['identical'] for group in proof.values() for r in group)
