"""Cross-check full physical CSV2DEV transcripts under explicit frozen v5 and Kaiser settings."""
from concurrent.futures import ProcessPoolExecutor
import json,os
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import phase1_gate as gate
from sts2rl.run_bundle import load_bundle

def episode(job):
    arm,bundle,mode,i=job
    def load(_):
        role, opts=load_bundle(bundle)
        if arm=="kaiser":
            opts["combat_search_v2_config"]=os.environ["KAISER_CONFIG"]
        return role,opts
    with TemporaryDirectory() as tmp, patch.object(gate,"load_bundle",load), patch.object(gate,"ROOT",Path.cwd()):
        return gate.episode((Path(os.environ["CSV2DEV_HOST"]),Path(tmp),arm,mode,i,False,False,False))

if __name__=="__main__":
    import sys
    arm,path,out=sys.argv[1:]
    with ProcessPoolExecutor(12) as pool:
        rows=list(pool.map(episode,[(arm,path,mode,i) for i in range(12) for mode in ("default","seeded")]))
    Path(out).write_text(json.dumps(rows))
