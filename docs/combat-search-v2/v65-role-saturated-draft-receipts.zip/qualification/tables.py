import json
from pathlib import Path
from v65 import ARMS
from report_v64 import CARDS
from sts2rl.draft_v65 import prohibited
from sts2rl.unified_draft import catalog,normalize

doc = Path("docs/combat-search-v2")
data = json.loads((doc/"v65-role-saturated-draft.json").read_bytes())
arms = [data["arms"][k] for k in ARMS]
out = []
labels = ["Control","A · trap cleanup","B · role saturation"]
def table(headers,rows):
    out.append("| "+" | ".join(headers)+" |")
    out.append("| "+" | ".join(["---"]*len(headers))+" |")
    out.extend("| "+" | ".join(map(str,row))+" |" for row in rows)
    out.append("")
def row(title,get):
    return [title,*[get(a) for a in arms]]
def rate(n,d):
    return f"{n}/{d} ({100*n/d:.1f}%)" if d else "0/0 (—)"
def ci(p):
    return f"{p['delta']:+.2f} [{p['ci95'][0]:+.2f}, {p['ci95'][1]:+.2f}]"
def wlt(p):
    return f"{p['w']}/{p['l']}/{p['t']}"
def title(name):
    out.extend(["## "+name,""])
out.extend(["# Silent A10 v6.5 development ablation","",Path("artifacts/v65/conclusion.md").read_text(encoding="utf8").strip(),""])
title("Paired CSV10DEV progression")
paired = [data["paired"][k] for k in ARMS[1:]]
rows=[row("Natural starts",lambda a:a["n"]),row("Mean global floor",lambda a:f"{a['mean_floor']:.3f}"),
      ["Difference vs Control [95% paired CI]","—",*map(ci,paired)],
      ["Floor W/L/T vs Control","—",*map(wlt,paired)],
      ["Two-sided exact sign p","—",*[f"{p['sign_p']:.5g}" for p in paired]]]
for label,key in [("Act 1 clears","a1_clears"),("Act 2 boss entries","a2_entries"),("Act 2 clears","a2_clears")]:
    rows.append(row(label,lambda a:a[key]))
for boss in sorted(set.union(*(set(a["bosses"]) for a in arms))):
    rows.append(row(boss+" clears / entries",lambda a:rate(*a["bosses"].get(boss,[0,0]))))
rows += [row("Act 3 boss entries",lambda a:a["a3_entries"]),row("Full wins",lambda a:a["wins"]),
         row("Combat latency p50 / p95 (ms)",lambda a:f"{a['p50_ms']:.3f} / {a['p95_ms']:.3f}"),
         row("Registered native matches / mismatches / unresolved",lambda a:" / ".join(f"{a['native'][k]:,}" for k in ("match","mismatch","unresolved"))),
         row("Combat decisions",lambda a:f"{a['combat_steps']:,}"),
         row("Native matches per 100 combat decisions",lambda a:f"{a['native_matches_per_100_combat_decisions']:.2f}")]
if data["independent_audit"]:
    rows.append(["Independent native matches / mismatches / unresolved", *[
        " / ".join(f"{data['independent_audit'][arm]['native'][k]:,}" for k in ("match","mismatch","unresolved"))
        for arm in ARMS]])
table(["Outcome",*labels],rows)
p=data["b_vs_a"]
out.extend([f"B minus A was {ci(p)} floors, with W/L/T {wlt(p)} and exact sign p = {p['sign_p']:.5g}.","",
            "Global floor is 17 × (act − 1) + floor. The 95% intervals use 50,000 paired bootstrap resamples within act-list mode. Exact two-sided sign tests omit tied seeds. Boss conversion uses entrants to that boss as its denominator. Native unresolved counts include simulator boundaries. Latency pools physical combat decisions.",""])
title("Deck size and optional reward skips")
rows=[]
for act in "123":
    rows.append(row("Act "+act+" final observed deck size",lambda a:f"{a['deck_size'][act]['mean']:.2f} (n={a['deck_size'][act]['n']})"))
    rows.append(row("Act "+act+" reward skips",lambda a:rate(a["reward_skip"][act]["skips"],a["reward_skip"][act]["optional"])))
table(["Outcome",*labels],rows)
title("Pre-flight scoring")
out.extend([(doc/"v65-protocol.md").read_text(encoding="utf8").split("## Synthetic scores before CSV10DEV")[1].split("[Cohort lock]")[0].strip(),""])
title("Eligibility audit")
table(["Acquisition audit",*labels],[row(label,lambda a:a["hard_skip_audit"][k]) for k,label in
    [("offered","Ineligible card appearances"),("picked","Ineligible copies acquired"),
     ("avoidable","Avoidable ineligible acquisitions"),("unavoidable","Mandatory ineligible acquisitions")]])
out.extend(["The audit rechecks the actual public energy and channel-source count at each decision. A mandatory choice is avoidable if a legal alternative contains fewer blocked cards. Shop audit counts include repeated visits to stock within the same shop.",""])
blocked_names={k for k in catalog() if prohibited(normalize({"id":k}),3,0)}
names=CARDS+sorted(blocked_names-set(CARDS))
for source,label in [("card_reward","Reward picks per offer"),("all","Picks across rewards, shops and bundles")]:
    title(label)
    rows=[]
    for k in names:
        values=[a["cards"][source].get(k,{"picked":0,"offered":0}) for a in arms]
        if k in CARDS or k in ("CLASH","THE_GAMBIT","PANIC_BUTTON") or any(x["offered"] for x in values):
            old=data["historical_csv9dev_b"]["cards"][source].get(k,{"picked":0,"offered":0})
            rows.append([catalog()[k]["name"],rate(old["picked"],old["offered"]),*[rate(x["picked"],x["offered"]) for x in values]])
    table(["Card","v6.4 B · CSV9DEV",*labels],rows)
out.extend(["Reward denominators count card appearances. The combined table counts stocked slots once per shop visit, including unaffordable stock, and counts every card in each bundle. Routes and survival change which offers each policy reaches. The JSON includes counts by individual offer source.",""])
title("Native hidden-order differential")
out.extend(["On CSV10DEV_DEFAULT_0147 at Act 2 floor 3, round 1 against two Exoskeletons, ending the turn was forced. The player had 49 HP, zero block, and I Am Invincible in a 16-card unordered draw pile. The frozen observer predicted 43 HP. When I Am Invincible was on top, it played automatically and the host returned 49 HP. Putting it last produced the predicted 43 HP. Both experiments replayed the same command prefix and public root hash before setting the test-only hidden permutation.",""])
if data["independent_audit"]:
    out.extend([f"At audit commit `{data['audit_manifest']['commit']}`, a second observer identified mixed draw piles containing the autoplay card before requesting the successor. It labeled relevant end turns unresolved for either outcome. Across the 1,152 repeat starts, every executed command digest, offer, deck count, terminal outcome and frozen native verdict matched the registered run. The archive carries both complete passes. The published latency is from the registered pass.",""])
    table(["Pre-step boundary reclassification",*labels],[
        [label,*[data["independent_audit"][arm]["boundaries"].get(key,0) for arm in ARMS]]
        for key,label in [("match","Previously matching end turns"),("mismatch","Previously mismatching end turns"),
                          ("unresolved","Previously unresolved end turns")]])
title("Qualification and reproduction")
q=data["qualification"]
out.extend([f"The pre-registered policy and cohort commit was `{data['manifest']['commit']}`. All 384 names and seed hashes were disjoint from {q['cohort']['historical_names']:,} historical or reserved names. The collector checked both pinned runtime hashes and used twelve workers with one thread each for OpenBLAS and OpenMP.","",
            f"All {len(q['profiles'])} previous builders reproduced every policy file byte for byte. The {len(q['frozen'])} released challenger files matched the Git blobs at efd9877. The 24 off, 24 active and 24 shadow CSV2DEV receipts were exact. Another 24 frozen-v5 and 24 Kaiser CSV2DEV transcripts matched their historical references. Four archived CSV9DEV starts per profile also matched Control and both v6.4 configurations on every deterministic receipt field.","",
            Path("artifacts/v65/final-verification.md").read_text(encoding="utf8").strip(),"",
            "The collector and analysis can be rerun with the pinned environment.","",
            "```powershell","python docs/combat-search-v2/probes/v65.py artifacts/v65/dev --workers 12",
            "python docs/combat-search-v2/probes/v65.py artifacts/v65/reaudit --workers 12 --audit-draw-order",
            "python docs/combat-search-v2/probes/report_v65.py docs/combat-search-v2/v65-role-saturated-draft-receipts.zip docs/combat-search-v2/v65-role-saturated-draft.json","```","",
            "[Protocol and synthetic scores](v65-protocol.md) · [Seed lock](csv10dev-lock.json) · [Machine-readable results](v65-role-saturated-draft.json) · [Receipts](v65-role-saturated-draft-receipts.zip)"])
(doc/"v65-role-saturated-draft-report.md").write_text("\n".join(out)+"\n",encoding="utf8")
