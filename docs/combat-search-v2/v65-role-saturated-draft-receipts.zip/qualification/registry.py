"""Check natural names, including nested compressed releases and generated registries."""
import gzip,hashlib,io,json,re,subprocess,zipfile
from pathlib import Path
from sts2rl.combat_search_v2 import seed_registry as reg
from ctypes import c_uint64
def u(x): return c_uint64(x).value
def rol(x,k): return u(x<<k)|(x>>(64-k))
# XXH64, seed 0. Include full stripes for longer historical scenario IDs.
P1,P2,P3,P4,P5=11400714785074694791,14029467366897019727,1609587929392839161,9650029242287828579,2870177450012600261
def mix(x,n):return u(rol(u(x+n*P2),31)*P1)
def xx(s):
    data=s.encode();i=0
    def word(at,n):return int.from_bytes(data[at:at+n],"little")
    if len(data)>=32:
        v=[u(P1+P2),P2,0,u(-P1)]
        while i+32<=len(data):
            v=[mix(x,word(i+8*j,8)) for j,x in enumerate(v)];i+=32
        h=u(sum(rol(x,k) for x,k in zip(v,(1,7,12,18))))
        for x in v:h=u((h^mix(0,x))*P1+P4)
    else:h=P5
    h=u(h+len(data))
    while i+8<=len(data):h=u(rol(h^mix(0,word(i,8)),27)*P1+P4);i+=8
    if i+4<=len(data):h=u(rol(h^u(word(i,4)*P1),23)*P2+P3);i+=4
    for n in data[i:]:h=u(rol(h^u(n*P5),11)*P1)
    h=u((h^(h>>33))*P2);h=u((h^(h>>29))*P3);return h^(h>>32)
assert xx("")==0xef46db3751d8e999 and xx("abc")==0x44bc2cf5ad770999
seeds=set()
pattern=rb"\b(?:VAL256|SEEDED128|TRUE_SEEDED|REP512|(?:CSV[2-9]|CSV10)|AUDIT384|FINAL768|M4|V5)[A-Z0-9_]*"
def forbidden(name): return any(x in name.lower() for x in ("final768","pooled896","rep512","seeded128","true_seeded","val256"))
def scan(name,data):
    if forbidden(name):
        return
    if name.endswith(".gz"):scan(name[:-3],gzip.decompress(data))
    elif name.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for n in archive.namelist():
                if not forbidden(n):scan(n,archive.read(n))
    elif name.endswith((".md",".py",".json",".jsonl",".txt",".ps1")):
        seeds.update(v.decode() for v in re.findall(pattern,data))
# Scan every historical text or archive blob reachable from the original fetched refs.
refs=json.loads(Path(__file__).with_name("historical-ref-oids.json").read_bytes())
objects=subprocess.check_output(["git","rev-list","--objects",*refs],text=True,encoding="utf-8").splitlines()
candidates={}
for line in objects:
    oid,_,path=line.partition(" ")
    if not forbidden(path) and path.endswith((".gz",".zip",".md",".py",".json",".jsonl",".txt",".ps1")):
        candidates[oid]=path
blobs=subprocess.Popen(["git","cat-file","--batch"],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
try:
    for oid,path in candidates.items():
        blobs.stdin.write((oid+"\n").encode());blobs.stdin.flush()
        header=blobs.stdout.readline().split()
        raw=blobs.stdout.read(int(header[-1]));assert blobs.stdout.read(1)==b"\n"
        if header[1]==b"blob":scan(path,raw)
finally:
    blobs.stdin.close()
    assert blobs.wait()==0
for fun in (reg.registry,reg.phase3_registry,reg.confirmation_registry,reg.phase3_confirmation_registry):
    seeds.update(l.seed for l in fun())
prefixes={re.sub(r"[0-9]+$","",s) for s in seeds if re.search(r"_\d{2,}$",s)}
for p in prefixes:seeds.update(f"{p}{i:04d}" for i in range(1024))
# Reserve ordinal namespaces for unpublished future panels as well.
for prefix in ("FINAL768", "FINAL768B", "REP512", "SEEDED128", "TRUE_SEEDED", "VAL256", "POOLED896"):
    for tag in ("", "_DEFAULT", "_SEEDED", "_DEF", "_SED"):
        seeds.update(f"{prefix}{tag}_{i:04d}" for i in range(1024))
lock=Path("docs/combat-search-v2/csv10dev-lock.json").read_bytes()
names={s for i,s,m in json.loads(lock)}
official=json.loads(Path("releases/silent-a10-v2-tactics/benchmark.json").read_bytes())["seed_order"]
assert all(s in seeds for rr in official.values() for i,s,m in rr)
assert len(names)==len(set(map(xx,names)))==384 and not names & seeds and not set(map(xx,names)) & set(map(xx,seeds))
proof=dict(sha256=hashlib.sha256(lock).hexdigest(),count=len(names),historical_names=len(seeds),
           expanded_prefixes=len(prefixes),fetched_tip_count=len(refs),scanned_git_objects=len(candidates),tip_set_sha256=hashlib.sha256("\n".join(refs).encode()).hexdigest(),official=sum(map(len,official.values())),name_overlaps=0,xxhash64_overlaps=0)
print(proof)
Path("artifacts/v65/cohort-proof.json").write_text(json.dumps(proof))
