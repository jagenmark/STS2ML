"""Verify frozen bytes, compatibility transcripts and historical builder output."""
import gzip
import hashlib
import json
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import runpy
import subprocess
from tempfile import TemporaryDirectory
import zipfile

import v64

def sha(data):
    return hashlib.sha256(data).hexdigest()

if __name__ == "__main__":
    root = Path.cwd()
    work = root / "artifacts/v65"
    previous = (root / "../t3-d752444c-44444aad7292a78f").resolve()
    assert subprocess.check_output(["git", "-C", str(previous), "rev-parse", "HEAD"], text=True).strip().startswith("37afd57")
    qualification = dict(profiles={}, frozen={}, compat={}, v64_replays={})
    base = Path("releases/silent-a10-mecha-knight/challenger/policy.json")
    release = Path("releases/silent-a10-v2-tactics/challenger")
    entries = subprocess.check_output(["git","ls-tree","-r","--name-only","efd9877","--",str(release)],text=True).splitlines()
    assert set(map(Path,entries)) == {p for p in release.rglob("*") if p.is_file()}
    for name in entries:
        original = subprocess.check_output(["git","show","efd9877:"+name])
        assert original == Path(name).read_bytes()
        qualification["frozen"][name] = sha(original)
    ref, cur = [runpy.run_path(str(p/"scripts/build-batch1-challengers.py")) for p in (previous, root)]
    with TemporaryDirectory() as temp, zipfile.ZipFile(v64.DOC/"v64-unified-draft-receipts.zip") as archive:
        jobs = []
        for profile in ref["PROFILES"]:
            outputs = [m["build_batch1_bundle"](p/base, Path(temp)/k/profile, profile=profile)
                       for p,k,m in [(previous,"before",ref),(root,"now",cur)]]
            def snapshot(path):
                return {x.relative_to(path.parent).as_posix():sha(x.read_bytes()) for x in path.parent.rglob("*") if x.is_file()}
            before,after = map(snapshot,outputs)
            assert before == after
            qualification["profiles"][profile] = after
            if profile in v64.ARMS:
                for triple in v64.cohort()[:4]:
                    jobs.append((outputs[1].parent.parent,outputs[1],triple))
        with ProcessPoolExecutor(12) as pool:
            futures = [pool.submit(v64.episode,*job) for job in jobs]
            for f in futures: f.result()
        for arm in v64.ARMS:
            archived = list(map(json.loads,gzip.decompress(archive.read(arm+".jsonl.gz")).splitlines()))
            for row in archived[:4]:
                seed = row["seed"]
                data = json.loads(gzip.decompress((Path(temp)/"now"/arm/(seed+".json.gz")).read_bytes()))
                del data["latency_us"],row["latency_us"]
                assert data == row, (arm,seed)
                qualification["v64_replays"][arm+"/"+seed] = row["commands"]
        for mode in ["off","active","shadow"]:
            candidate = json.loads((work/(mode+".json")).read_bytes())
            assert candidate == json.loads(archive.read("qualification/"+mode+".json"))
            qualification["compat"][mode] = len(candidate)
        for arm in ("v5","kaiser"):
            actual = json.loads((work/(arm+"-candidate.json")).read_bytes())
            assert actual == json.loads(archive.read("qualification/"+arm+"-reference.json"))
            qualification["compat"][arm] = len(actual)
    (work/"qualification.json").write_text(json.dumps(qualification,indent=2))
    print(len(qualification["profiles"]),len(qualification["frozen"]),qualification["compat"])
