import gzip
import json
from pathlib import Path
import zipfile
from v65 import ARMS, cohort
from v64 import DOC

folder = Path("artifacts/v65")
archive = DOC / "v65-role-saturated-draft-receipts.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=8) as z:
    z.write(folder/"dev/manifest.json", "manifest.json")
    for arm in ARMS:
        records = []
        for _,seed,mode in cohort():
            data = gzip.decompress((folder/"dev"/arm/(seed+".json.gz")).read_bytes())
            row = json.loads(data)
            assert row["seed"] == seed and row["act_list"] == mode
            assert row["status"] == "complete" and not row["error"] and not row["abandoned"]
            records.append(data)
        z.writestr(arm+".jsonl.gz",gzip.compress(b"\n".join(records)+b"\n",mtime=0))
    rerun = folder/"reaudit"
    if (rerun/"manifest.json").exists():
        z.write(rerun/"manifest.json","reaudit/manifest.json")
        for arm in ARMS:
            records = [gzip.decompress((rerun/arm/(seed+".json.gz")).read_bytes()) for _,seed,_ in cohort()]
            z.writestr("reaudit/"+arm+".jsonl.gz",gzip.compress(b"\n".join(records)+b"\n",mtime=0))
        for name in ("final-tests.log","final-ruff.log"):
            z.write(folder/name,"qualification/"+name)
    for name in ("registry.py","historical-ref-oids.json","qualify.py","cohort-proof.json",
                 "qualification.json","preflight.json","registered-tests.log",
                 "pack.py","tables.py","conclusion.md","final-verification.md","kaiser_fixture_guard.py","off.json","active.json","shadow.json",
                 "v5-candidate.json","kaiser-candidate.json"):
        z.write(folder/name,"qualification/"+name)
print(archive,archive.stat().st_size)
