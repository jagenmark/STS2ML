"""Enforce the requested panel exclusions on top of the existing fixture remaps."""
import pytest

from sts2rl.native import NativeSession

original = NativeSession.reset
forbidden = ("FINAL768", "VAL256", "SEEDED128", "TRUE_SEEDED", "REP512", "POOLED896")


def reset(self, seed, *args, **kwargs):
    if seed.startswith(forbidden):
        if seed == "FINAL768_DEFAULT_0037":
            pytest.skip("reserved natural lobby; fresh CSV7FIX poison-before-Defend differential runs separately")
        raise AssertionError("Reserved native lobby " + seed)
    return original(self, seed, *args, **kwargs)


NativeSession.reset = reset
