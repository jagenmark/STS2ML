import sys,json
from pathlib import Path
from sts2rl.act1 import save_json
from sts2rl.run_bundle import freeze_bundle,load_bundle
parent,dest,edit=map(Path,sys.argv[1:])
role,settings=load_bundle(parent);enc=json.loads(settings['encounter_model'].read_bytes());spec=json.loads(edit.read_bytes())
for k,v in spec.items():
 if k=='fallback':
  hallway=enc.setdefault('act2_hallways',{'plans':{},'by_formation':{}});hallway['plans']['fallback']=v;hallway['by_room']={'Monster':'fallback','Elite':'fallback'}
 elif k=='overlay':
  for name,plan in v.items():
   hall=enc.setdefault('act2_hallways',{'plans':{},'by_formation':{}});hall['plans'][name]=plan;hall['by_formation'][name]=name
 else:enc[k]=v
dest.mkdir(parents=True,exist_ok=False);save_json(dest/'encounter.json',enc);settings['encounter_model']=dest/'encounter.json';freeze_bundle({'args':{**settings,'roles':[role]}},dest/'policy')
