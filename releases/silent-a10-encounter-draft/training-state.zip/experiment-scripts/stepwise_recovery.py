"""Replay any inconclusive bulk restorations with the original native command boundary."""
import json,sys
from pathlib import Path
from tempfile import TemporaryDirectory
from sts2rl.native import NativeSession,digest
from sts2rl.run_evaluation import verified_victory
w,host,evaluation,receipts=map(Path,sys.argv[1:])
rows=json.loads((receipts/'receipts.json').read_bytes())
files={json.loads(f.read_bytes())['seed']:f for f in (evaluation/'candidate').glob('run-*/result.json')}
for row in rows:
    if row['verified']:continue
    f=files[row['seed']];expected=json.loads(f.read_bytes());location=0
    try:
        with TemporaryDirectory() as tmp, NativeSession(w,Path(tmp)/'game',host_path=host,act_list='seeded') as game, (f.parent/'game/rpc.jsonl').open() as stream:
            actions=0
            for location,line in enumerate(stream):
                record=json.loads(line);cmd=record['command']
                if cmd['cmd'] not in ('training_restore','action','get_map') or (cmd['cmd']=='training_restore' and (location or cmd['history'])):raise ValueError('unexpected command')
                state=game._request(cmd);actual=digest(state)
                if actual!=record['response_digest']:raise ValueError('per-command state differs')
                actions+=cmd['cmd']=='action'
            if state['decision']!='game_over' or state['victory']!=expected['win'] or (expected['win'] and not verified_victory(expected['boss_fights'])):raise ValueError('native terminal discrepancy')
            row.update(verified=True,actions=actions,terminal=actual,proof='per-command native replay')
            row.pop('error',None)
    except (ValueError,RuntimeError,TimeoutError) as e:row.update(stepwise_failure={'rpc_index':location,'reason':str(e)})
(receipts/'receipts-final.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Independently verified native receipts',sum(r['verified'] for r in rows),'of',len(rows))
