import gzip,hashlib,json,math,sys
from collections import Counter,defaultdict
from pathlib import Path
from sts2rl.native import digest
from sts2rl.provenance import draft_scorer_hash
from sts2rl.strategy import strategy_kind
root, bundle, dest = map(Path,sys.argv[1:])
files=json.loads(bundle.read_bytes())['files']
models={k:files[k]['sha256'] if k in files else None for k in ('weights','strategy_model','offer_model','late_weights')}
results={'games':0,'drafts':0,'alternatives':0,'skips':0,'different_from_prior':0,'by_act':{},'group_probability_known':0,
         'every_draft_matches_executed_native_command':True,'scorer_sha256':draft_scorer_hash(),'model_sha256':models}
for path in sorted((root/'candidate').glob('run-*/draft-scores.jsonl.gz')):
    folder=path.parent;results['games']+=1;native=[]
    with (folder/'game/rpc.jsonl').open() as rpc:
        for line in rpc:
            row=json.loads(line)
            if row['command']['cmd']=='action':native.append(row['command'])
    with gzip.open(folder/'strategy.jsonl.gz','rt') as dataset:
        real=[r for line in dataset if (r:=json.loads(line))['state']['decision']=='card_reward' and not r['state'].get('in_combat')]
    logs=[json.loads(line) for line in gzip.open(path,'rt')]
    if [r['step'] for r in real]!=[r['step'] for r in logs]:raise ValueError(f'Coverage mismatch {folder.name}')
    for stored,trace in zip(real,logs,strict=True):
        if trace['model_sha256']!=models or trace['scorer_sha256']!=draft_scorer_hash():raise ValueError('Wrong model provenance in draft')
        if not (digest(stored['state'])==trace['state_digest'] and stored['action']==native[trace['step']]==trace['chosen_action']):raise ValueError('Physical decision mismatch')
        options=trace['options'];prior=max(options,key=lambda a:a['prior']);win=max(options,key=lambda a:a['total'])
        if win['action']!=trace['chosen_action']: raise ValueError('Ranking mismatch')
        for a in options:
            terms=[a['prior_base_parts'].values(),[z['points'] for z in a['prior_terms'].values()],[z['points'] for z in a['strategy_terms'].values()]]
            base,opening,strategy=map(sum,terms)
            if not all(math.isclose(x,y,abs_tol=1e-8) for x,y in ((a['prior_base'],base),(a['prior'],base+opening),(a['strategy'],strategy),(a['total'],a['prior']+a['strategy']+a['card_offset']))):
                raise ValueError('Inconsistent score components')
        results['drafts']+=1;results['alternatives']+=len(options);results['different_from_prior']+=prior!=win;results['skips']+=win['card']=='skip'
        results['group_probability_known']+=trace['group_probability'] is not None
        a=results['by_act'].setdefault(str(trace['context']['act']),{'drafts':0,'skips':0,'different_from_prior':0})
        a['drafts']+=1;a['skips']+=win['card']=='skip';a['different_from_prior']+=prior!=win
dest.write_text(json.dumps(results,indent=2)+'\n')
print(results)
