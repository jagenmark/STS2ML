import gzip,json,sys,hashlib
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from tempfile import TemporaryDirectory
from sts2rl.encounter import EncounterModel
from sts2rl.native import NativeSession,legal_actions
from sts2rl.run_policy import RunPolicy,RunWeights,_damage
from sts2rl.teacher import incoming
from sts2rl.trajectory import strategy_roots
w,rooms,ckpt,host,out=map(Path,sys.argv[1:])
def kaiser(s):
    return s['decision']=='combat_play' and s['context']['room_type']=='Boss' and (s['context'].get('boss')or{}).get('id')=='KAISER_CRAB_BOSS'
def turn_towards(s,original,margin):
    if margin==0 or original.kind!='play_card' or 'target_index' not in original.args:
        return original
    enemies={e['index']:e for e in s['enemies'] if e['hp']>0}
    ix=original.args['target_index']; ci=original.args['card_index']
    if len(enemies)!=2 or ix not in enemies: return original
    target=enemies[ix];other=next(e for i,e in enemies.items() if i!=ix)
    card=next(c for c in s['hand'] if c['index']==ci)
    if _damage(card,target)>=target['hp']+target['block'] or incoming(other)-incoming(target)<margin: return original
    return next((a for a in legal_actions(s) if a.kind==original.kind and a.args.get('card_index')==ci and a.args.get('target_index')==other['index']), original)
def run(path):
    _,fork=next((s,f) for s,f in strategy_roots(path) if kaiser(s))
    results={}
    try:
        with TemporaryDirectory() as tmp, NativeSession(w,Path(tmp)/'game',host_path=host,act_list=fork.specification.get('act_list','default')) as game:
            for margin in (0,1,6,12):
                enc=EncounterModel.load(ckpt/'encounter_model.json');policy=RunPolicy(RunWeights.load(ckpt/'weights.json'));s=game.restore(fork);changes=0
                for j in range(300):
                    if s['decision']=='game_over' or not s.get('in_combat'): break
                    a=enc.choose(s,policy)
                    if s['decision']=='combat_play':
                        remaining=sum(e['hp'] for e in s['enemies']);rnd=s['round'];new=turn_towards(s,a,margin);changes+=a!=new;a=new
                    s=game.step(a)
                else:raise ValueError('action budget')
                win=s['decision']!='game_over';results[margin]={'won':win,'hp':s['player']['hp'],'enemy':0 if win else remaining,'round':rnd,'changes':changes}
    except (RuntimeError,ValueError,TimeoutError) as e:return {'seed':fork.specification['seed'],'root':fork.expected_digest,'error':str(e)}
    return {'seed':fork.specification['seed'],'root':fork.expected_digest,'outcomes':results}
if __name__=='__main__':
    paths=[]
    for p in sorted(rooms.glob('*/run-*/result.json')):
        r=json.loads(p.read_bytes());f=p.with_name('strategy.jsonl.gz')
        if r['status']!='complete' or r.get('opening_partition')=='test' or not any(a==2 for a,_ in r['boss_fights']) or not f.is_file(): continue
        with gzip.open(f,'rt') as stream:
            if any(kaiser(json.loads(l)['state']) for l in stream): paths.append(p.parent)
    out.mkdir()
    with ProcessPoolExecutor(2) as pool:
        for row in pool.map(run,paths):(out/(row['seed']+'.json')).write_text(json.dumps(row,indent=2)+'\n')
