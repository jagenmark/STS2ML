"""Compare the candidate with both frozen controls on the precommitted seed collection."""

import gzip
import json
import sys
from collections import Counter
from hashlib import sha256
from math import comb
from pathlib import Path

root = Path(sys.argv[1])
selection = json.loads((root/'selection.json').read_bytes())
candidate = selection['candidate']
lock = json.loads((root/'seed-lock.json').read_bytes())
seeds = lock['seeds']['test']
arms = {'release': 'release', 'control': 'control', 'candidate': candidate}
measures = ('win', 'a2_clear', 'a1_clear')
games = {}
receipts = {}
output = {'candidate': candidate, 'paired_initial_states': 0, 'arms': {}, 'pairs': {}, 'seed_count': len(seeds)}
for arm, folder in arms.items():
    rows = {}
    for path in sorted((root/(folder+'-blind')/'candidate').glob('run-*/result.json')):
        x = json.loads(path.read_bytes())
        with (path.parent/'game/rpc.jsonl').open() as stream:
            first = json.loads(next(stream))
        if x['seed'] in rows:
            raise ValueError('Duplicate seed')
        rows[x['seed']] = {**{k: x[k] for k in ('status','win','a1_clear','a2_clear','act_names','floor','act','boss_fights','last_enemies')},
                           'opening_digest': first['response_digest'], 'initial_command': first['command']}
    if set(rows) != set(seeds):
        raise ValueError('Seed set differs from the lock')
    games[arm] = rows
    rp = root/(folder+'-replay')
    recs = json.loads((rp/('receipts-final.json' if (rp/'receipts-final.json').exists() else 'receipts.json')).read_bytes())
    receipts[arm] = {r['seed']:r for r in recs}
    if set(receipts[arm]) != set(seeds):
        raise ValueError('Missing terminal receipts')
    output['arms'][arm] = {'complete':sum(r['status']=='complete' for r in rows.values()),
                           'verified':sum(r['verified'] for r in recs),
                           'raw':{m:sum(r[m] for r in rows.values()) for m in measures},
                           'boss_entries_by_act':{str(act):sum(any(a==act for a,_ in r['boss_fights']) for r in rows.values()) for act in (1,2,3)},
                           'last_enemies_in_act_3':dict(Counter('+'.join(r['last_enemies']) for r in rows.values() if r['act']==3)),
                           'failed_replays':[r['seed'] for r in recs if not r['verified']]}
for seed in seeds:
    opening = games['release'][seed]
    for arm in arms:
        row = games[arm][seed]
        if (row['opening_digest'],row['initial_command']) != (opening['opening_digest'],opening['initial_command']):
            raise ValueError('Different native opening for the same seed')
    output['paired_initial_states'] += 1
for other in ('release','control'):
    pairs = [s for s in seeds if all(receipts[a][s]['verified'] and games[a][s]['status']=='complete' for a in ('candidate',other))]
    sums = {a:{m:sum(games[a][s][m] for s in pairs) for m in measures} for a in ('candidate',other)}
    by_biome = {}
    for biome in sorted({games[other][s]['act_names'][0] for s in pairs}):
        ss = [s for s in pairs if games[other][s]['act_names'][0]==biome]
        by_biome[biome] = {'n':len(ss), **{a:{m:sum(games[a][s][m] for s in ss) for m in measures} for a in sums}}
    discordance = {}
    for m in measures:
        gained = sum(games['candidate'][s][m] and not games[other][s][m] for s in pairs)
        lost = sum(not games['candidate'][s][m] and games[other][s][m] for s in pairs)
        n = gained+lost
        p = min(1,2*sum(comb(n,k) for k in range(min(gained,lost)+1))/2**n)
        discordance[m] = {'candidate_only':gained,'reference_only':lost,'exact_two_sided_p':p}
    output['pairs'][other] = {'n':len(pairs),'counts':sums,'by_biome':by_biome,'discordance':discordance}
with gzip.open(root/'test-games.jsonl.gz','wt',encoding='utf-8') as stream:
    for seed in seeds:
        row = {'seed':seed,'opening_digest':games['release'][seed]['opening_digest']}
        for a in arms:
            g = games[a][seed]
            row[a] = {**{k:v for k,v in g.items() if k not in ('opening_digest','initial_command')},'replay':receipts[a][seed]}
        stream.write(json.dumps(row,separators=(',',':'))+'\n')
(root/'test-report.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output['arms']))
print(json.dumps(output['pairs']))
