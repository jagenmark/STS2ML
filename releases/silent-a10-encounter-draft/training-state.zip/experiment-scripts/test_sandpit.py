import gzip,json,sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from tempfile import TemporaryDirectory
from sts2rl.encounter import EncounterModel
from sts2rl.native import NativeError,NativeSession,legal_actions
from sts2rl.run_policy import RunPolicy,RunWeights
from sts2rl.sandpit import escape_action
from sts2rl.trajectory import strategy_roots
w,b,out=map(Path,sys.argv[1:4]);assets=b/'artifacts/helmer-release/from-github';ckpt=assets/'silent-a10-progression-release/challenger'
host=b/'artifacts/a10-push/host-v9/src/Sts2Headless/bin/Curriculum/net9.0/Sts2Headless.dll'
def run(source):
 _,f=next((s,f) for s,f in strategy_roots(source) if s['decision']=='combat_play' and s['context']['room_type']=='Boss' and s['context']['act']==2 and s['context']['boss']['id']=='THE_INSATIABLE_BOSS')
 rows={}
 try:
  with TemporaryDirectory() as tmp,NativeSession(w,Path(tmp)/'game',host_path=host,act_list=f.specification.get('act_list','default')) as g:
   for n in [0,1,2,3,4]:
    s=g.restore(f);enc=EncounterModel.load(ckpt/'encounter_model.json');base=RunPolicy(RunWeights.load(ckpt/'weights.json'));round_=1;changes=0
    for _ in range(300):
     if s['decision']=='game_over' or not s.get('in_combat'): break
     a=enc.choose(s,base)
     if s['decision']=='combat_play':
      e=s['enemies'][0]; remaining=e['hp'];round_=s['round'];new=escape_action(s,legal_actions(s),a,n);changes+=new!=a;a=new
     s=g.step(a)
    else: raise RuntimeError('combat time budget')
    win=s['decision']!='game_over';rows[n]={'won':win,'hp':s['player']['hp'],'enemy':0 if win else remaining,'round':round_,'changes':changes}
 except (RuntimeError,ValueError,TimeoutError) as e: return {'seed':f.specification['seed'],'root':f.expected_digest,'error':str(e)}
 return {'seed':f.specification['seed'],'root':f.expected_digest,'outcomes':rows}
if __name__=='__main__':
 paths=[]
 for p in sorted((assets/'silent-a10-training-state/rooms').glob('*/run-*/result.json')):
  result=json.loads(p.read_bytes())
  if result['status']!='complete' or result.get('opening_partition')=='test' or not any(a==2 for a,_ in result.get('boss_fights',[])) or not p.with_name('strategy.jsonl.gz').exists():continue
  for line in gzip.open(p.with_name('strategy.jsonl.gz'),'rt'):
   s=json.loads(line)['state'];c=s.get('context',{})
   if s['decision']=='combat_play' and c.get('act')==2 and c.get('room_type')=='Boss' and (c.get('boss')or{}).get('id')=='THE_INSATIABLE_BOSS':
    paths.append(p.parent);break
 dest=out/'sandpit';dest.mkdir(exist_ok=False)
 with ProcessPoolExecutor(2) as pool:
  for row in pool.map(run,paths):
   (dest/(row['seed']+'.json')).write_text(json.dumps(row,indent=2)+'\n')
