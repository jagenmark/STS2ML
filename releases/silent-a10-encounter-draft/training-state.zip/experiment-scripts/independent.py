import json,sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from hashlib import sha256
from replay_existing import replay
w,host,out,evaluation=map(Path,sys.argv[1:])
out.mkdir(exist_ok=True)
files=sorted((evaluation/'candidate').glob('run-*/result.json'))
files=sorted(files,key=lambda f:sha256(('cross-host-19/'+json.loads(f.read_bytes())['seed']).encode()).digest())[:16]
if len(files)!=16:raise ValueError('sample incomplete')
params=[(w/'scripts/compare-silent-bundles.py',(host,out/'native','seeded',i,[f.parent for f in files[i::2]])) for i in range(2)]
if __name__=='__main__':
    with ProcessPoolExecutor(2) as pool:rows=[r for chunk in pool.map(replay,params) for r in chunk]
    proof={'host_sha256':sha256(host.read_bytes()).hexdigest(),'sampling':'lowest SHA-256 of cross-host-19/ + seed','rows':rows}
    (out/'receipts.json').write_text(json.dumps(proof,indent=2)+'\n')
    print('Cross-build receipts',sum(r['verified'] for r in rows),'of',len(rows))
