import json,sys
from collections import Counter
from hashlib import sha256
from pathlib import Path
p=Path(sys.argv[1])
def load(path):return json.loads(path.read_bytes())
def valid(seed):return int.from_bytes(sha256(seed.encode()).digest()[:4],'big')%5==0
def case_files(directory):
    return [load(f) for f in sorted((p/directory).glob('*.json')) if f.name!='manifest.json']
studies={'logging_parity':{'native_games':3,'rpc_requests':505,'draft_rewards':20,'identical_commands_and_response_digests':True}}
for name in ('sandpit','kaiser'):
    allrows=case_files(name);rows=[r for r in allrows if 'outcomes' in r]
    def metrics(group):return {'paired_roots':len(group),'thresholds':{k:{
        'wins':sum(r['outcomes'][k]['won'] for r in group),'sum_enemy_hp':sum(r['outcomes'][k]['enemy']for r in group),
        'sum_player_hp':sum(r['outcomes'][k]['hp']for r in group)} for k in rows[0]['outcomes']}}
    studies[name]={'attempted':len(allrows),'excluded':[r for r in allrows if 'error' in r],
                   'all':metrics(rows),'training':metrics([r for r in rows if not valid(r['seed'])]),
                   'validation':metrics([r for r in rows if valid(r['seed'])])}
source=case_files('confirmed-hallways');rows=[r for r in source if 'arms'in r]
pilot=load(p/'hallway-pilot-fit.json');known=set(pilot['training']+pilot['validation'])
def score(group,scale):
    choices=[(max(r['arms'],key=lambda a:a['prior']),max(r['arms'],key=lambda a:a['prior']+scale*a['area'])) for r in group]
    return {'n':len(choices),'changed':sum(a!=b for a,b in choices),
            'hp_gain_total':sum(b['hp']-a['hp'] for a,b in choices),'changed_clears':sum(b['won']-a['won']for a,b in choices)}
train=[r for r in rows if not valid(r['seed'])];val=[r for r in rows if valid(r['seed'])]
grid={v:score(train,v) for v in [0,.25,.5,1,2,3,4]}
full=max(grid,key=lambda v:(grid[v]['changed_clears'],grid[v]['hp_gain_total'],-v))
studies['hallway']={'attempted':len(source),'complete':len(rows),'excluded':[r for r in source if 'error'in r],
                    'seed_groups':{'training':len(train),'validation':len(val)},'fit_grid':grid,'weight_fit_on_all_training':full,
                    'validation_gain':score(val,full),'pilot_effective_weight':pilot['effective_weight'],
                    'new_roots_after_pilot':score([r for r in rows if r['seed'] not in known],pilot['effective_weight']),
                    'formations':dict(Counter('+'.join(r['arms'][0]['enemies']) for r in rows)),
                    'example':next(r for r in rows if r['seed']=='H2A10BIOMETRAIN0004')}
for name in ('draft-labels','late-labels','boss-labels'):
    shards=[load(f) for f in (p/name).glob('run-*/labels.json')]
    roots=[row for s in shards for row in s['roots']]
    studies[name]={'original_seeds':len(shards),'complete_roots':len(roots),'alternative_native_outcomes':sum(len(r.get('arms',r.get('styles',{}))) for r in roots),'errors':sum(len(s['errors'])for s in shards)}
rep=p/'independent-sandpit'
if (rep/'manifest.json').is_file():
    first={r['seed']:r for r in case_files('sandpit')}
    second={r['seed']:r for r in case_files('independent-sandpit')}
    shared=[s for s in first.keys() & second.keys() if 'outcomes' in first[s] and 'outcomes' in second[s]]
    matching=[s for s in shared if first[s]['root']==second[s]['root'] and all(
        all(first[s]['outcomes'][k][key]==val for key,val in out.items())
        for k,out in second[s]['outcomes'].items())]
    studies['sandpit']['independent_build']={'host_sha256':load(rep/'manifest.json')['host_sha256'],
        'attempted':len(second),'paired_complete':len(shared),'identical_all_five_thresholds':len(matching),
        'different':[s for s in shared if s not in matching],
        'wins_by_threshold':{k:sum(second[s]['outcomes'][k]['won']for s in shared)for k in ['0','1','2','3','4']}}
for fit in ('pilot','opening128','opening192','late48','late112'):
    f=p/(fit+'-fit')/'fit.json'
    if f.is_file():
        d=load(f);studies[fit+'-fit']={k:d[k] for k in ['train_roots','validation_roots','selected','excluded_contexts','label_files']}
bf=load(p/'boss-fit/fit.json');studies['boss_overrides']={k:bf[k] for k in ['overrides','validation_fights','validation_wins']}
route=load(p/'route-fit/fit.json');studies['route']={'seeds':len(route['seeds']),'boss_openings':route['boss_openings'],'censored_tiers':route['censored_tiers']}
(p/'studies.json').write_text(json.dumps(studies,indent=2)+'\n')
