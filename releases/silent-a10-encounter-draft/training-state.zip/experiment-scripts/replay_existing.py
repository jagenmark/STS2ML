import argparse
import json
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import runpy

def replay(shard):
    script, params = shard
    return runpy.run_path(str(script))['attest'](params)

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('worktree', type=Path)
    p.add_argument('host', type=Path)
    p.add_argument('evaluation', type=Path)
    p.add_argument('output', type=Path)
    p.add_argument('--workers', type=int, default=2)
    a = p.parse_args()
    a.output.mkdir(exist_ok=True)
    paths = sorted(f.parent for f in (a.evaluation/'candidate').glob('run-*/result.json'))
    if len(paths) != 192:
        raise ValueError('Expected all 192 locked native results')
    script = a.worktree/'scripts/compare-silent-bundles.py'
    def shard(paths, index, name):
        return script, (a.host, a.output/name, 'seeded', index, paths)
    shards = [shard(paths[i::a.workers], i, 'first') for i in range(a.workers)]
    with ProcessPoolExecutor(a.workers) as pool:
        rows = [r for block in pool.map(replay, shards) for r in block]
        by_seed = {json.loads((x/'result.json').read_bytes())['seed']:x for x in paths}
        failed = [r for r in rows if not r['verified']]
        if failed:
            (a.output/'first-failures.json').write_text(json.dumps(failed,indent=2)+'\n')
            tasks = [shard([by_seed[r['seed']]], i, 'retry') for i,r in enumerate(failed)]
            rows = [r for r in rows if r['verified']] + [r for chunk in pool.map(replay,tasks) for r in chunk]
    (a.output/'receipts.json').write_text(json.dumps(sorted(rows,key=lambda r:r['seed']),indent=2)+'\n')
    print('Replay receipts',len(rows),'verified',sum(r['verified'] for r in rows))
