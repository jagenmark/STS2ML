"""Freeze exactly one experimental bundle from completed development games."""
from datetime import datetime, timezone
from hashlib import sha256
import json,subprocess,sys
from pathlib import Path
work,root,reference,host=map(Path,sys.argv[1:])
rules=json.loads((root/'finalist-rules.json').read_bytes())
lock=json.loads((root/'seed-lock.json').read_bytes())['seeds']
dev={}
def hashfile(p):return sha256(p.read_bytes()).hexdigest()
def write(name,obj):
    with (root/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
for name in rules['tie_order']:
    p=root/(name+'-dev')
    tail=root/(name+'-tail')
    paths={}
    if (tail/'identity.json').exists():
        identity=json.loads((tail/'identity.json').read_bytes())
        if identity['bundle_sha256']!=hashfile(root/name/'policy.json') or identity['host_sha256']!=hashfile(host) or identity['prefix']!='A10POOLDEV19' or identity['profile']!='seeded':raise ValueError('Mismatched supplemental development shard')
        paths.update({f.parent.name:f for f in (tail/'candidate').glob('run-*/result.json')})
    paths.update({f.parent.name:f for f in (p/'candidate').glob('run-*/result.json')})
    files=sorted(paths.values())
    rows=[json.loads(f.read_bytes()) for f in files]
    if len(rows)!=len(lock['development']) or set(x['seed'] for x in rows)!=set(lock['development']) or any(x['status']!='complete' for x in rows):
        dev[name]={'eligible':False,'native_results_at_freeze':len(rows)}
        continue
    counts={m:sum(x[m] for x in rows) for m in ('win','a2_clear','a1_clear')}
    dev[name]={'eligible':True,'n':len(rows),**counts,'by_seed':{x['seed']:{m:x[m] for m in counts} for x in rows}}
eligible=[name for name in rules['tie_order'] if name!='control' and dev[name]['eligible']]
selected=max(eligible,key=lambda n:tuple(dev[n][m] for m in rules['order']))
bundle=root/selected/'policy.json'
stamp={'frozen_utc':datetime.now(timezone.utc).isoformat(),'candidate':selected,'bundle_sha256':hashfile(bundle),
       'components':json.loads(bundle.read_bytes())['files'],'feature_commit':subprocess.check_output(['git','-C',str(work),'rev-parse','HEAD'],text=True).strip(),
       'inference_source_sha256':{f.name:hashfile(f) for f in sorted((work/'src/sts2rl').glob('*.py'))},
       'host_sha256':hashfile(host),'reference_sha256':hashfile(reference),'seed_lock_sha256':hashfile(root/'seed-lock.json'),
       'rules':rules,'candidate_development':{k:v for k,v in dev[selected].items() if k!='by_seed'},
       'control_development':{k:v for k,v in dev['control'].items() if k!='by_seed'},
       'eligibility_at_freeze':{n:dict((k,v) for k,v in r.items() if k!='by_seed') for n,r in dev.items()}}
write('development.json',dev);write('selection.json',stamp)
print(selected,stamp['candidate_development'])
