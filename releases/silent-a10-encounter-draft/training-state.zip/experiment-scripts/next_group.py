"""Measure the immediate hallway return of group-damage picks at known weak-pool odds."""
import json,sys,hashlib
from pathlib import Path
from tempfile import TemporaryDirectory
from concurrent.futures import ProcessPoolExecutor
from collections import Counter
from sts2rl.encounter import EncounterModel
from sts2rl.native import NativeSession,legal_actions
from sts2rl.run_policy import RunPolicy,RunWeights
from sts2rl.routing import RoomModel
from sts2rl.offer_policy import OfferModel,offer_type
from sts2rl.strategy import StrategyModel,strategy_kind
from sts2rl.act1 import is_combat_choice
from sts2rl.encounter_draft import matchup_features
from sts2rl.trajectory import strategy_roots
w,rooms,ckpt,host,out=map(Path,sys.argv[1:]); p=out.parent
def simulate(game,root,action,baseline,offers,router):
    state=game.restore(root)
    actor=RunPolicy(RunWeights.load(ckpt/'weights.json'))
    combat=EncounterModel.load(ckpt/'encounter_model.json')
    enemies=None
    for _ in range(240):
        state=game.step(action);ctx=state.get('context',{});d=state['decision']
        if enemies and (d=='game_over' or not state.get('in_combat')):
            return {'enemies':enemies,'hp':max(0,state['player']['hp']),'won':d!='game_over'}
        if d=='game_over' or ctx.get('act')!=1:
            return None
        if d=='combat_play' and ctx['room_type']=='Monster' and enemies is None:
            enemies=sorted(e['id'] for e in state['enemies'])
        if d=='map_select':action=router.choose(state,game.public_map())
        elif is_combat_choice(state):action=combat.choose(state,actor)
        elif strategy_kind(state) in baseline.kinds:action=baseline.choose(state,actor,offers)
        elif offer_type(state):action=offers.choose(state,actor)
        else:action=actor(state)
    return None
def label(task):
    source,ctxfile=task;saved=json.loads(ctxfile.read_bytes());odds=saved['odds']
    possibilities=[]
    for s,f in strategy_roots(source):
        prob=odds.get(f.expected_digest);c=s.get('context',{})
        if s['decision']!='card_reward' or s.get('in_combat') or c.get('act')!=1 or prob is None or prob<0.5:continue
        strengths={card['index']:matchup_features(card,s['player']['deck'],c,prob).get('matchup/pool/area',0) for card in s['cards']}
        if any(strengths.values()):possibilities.append((prob,s,f,strengths))
    if not possibilities: return None
    prob,s,f,strengths=max(possibilities,key=lambda t:t[0]);result={'seed':saved['seed'],'root':f.expected_digest,'odds':prob}
    baseline=StrategyModel.load(ckpt/'strategy_model.json');offers=OfferModel.load(ckpt/'offer_model.json');router=RoomModel.load(ckpt/'room_model.json');trace={}
    baseline.choose(s,RunPolicy(RunWeights.load(ckpt/'weights.json')),offers,explanation=trace)
    tries=[]
    try:
        with TemporaryDirectory() as tmp,NativeSession(w,Path(tmp)/'game',host_path=host,act_list=f.specification.get('act_list','default')) as game:
            for action,option in zip(legal_actions(s),trace['options'],strict=True):
                if action.command()!=option['action']: raise ValueError('Action order changed')
                res=simulate(game,f,action,baseline,offers,router)
                if res is None:return {**result,'error':'No complete next hallway battle on every arm'}
                tries.append({**res,'card':option['card'],'prior':option['total'],'area':strengths.get(action.args.get('card_index'),0)})
    except (TimeoutError,RuntimeError,ValueError) as e:return {**result,'error':str(e)}
    if len({tuple(a['enemies']) for a in tries})!=1:return {**result,'error':'Different next hallway enemies'}
    return {**result,'arms':tries}
if __name__=='__main__':
    tasks=[]
    for src in [rooms/'biomes',rooms/'progression']:
        for f in sorted(src.glob('run-*/result.json')):
            r=json.loads(f.read_bytes());ctx=p/'contexts'/(r['seed']+'.json')
            if r['status']=='complete' and r.get('opening_partition')!='test' and ctx.is_file(): tasks.append((f.parent,ctx))
    out.mkdir()
    with ProcessPoolExecutor(2) as pool:
        for r in pool.map(label,tasks):
            if r:(out/(r['seed']+'.json')).write_text(json.dumps(r,indent=2)+'\n')
