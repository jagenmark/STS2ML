import argparse,json
from pathlib import Path
from sts2rl.run_bundle import freeze_bundle,load_bundle
p=argparse.ArgumentParser(); p.add_argument('parent',type=Path);p.add_argument('dest',type=Path);p.add_argument('--strategy',type=Path);p.add_argument('--encounter',type=Path);p.add_argument('--route',type=Path);args=p.parse_args()
role,settings=load_bundle(args.parent)
if args.strategy:settings['strategy_model']=args.strategy
if args.encounter:settings['encounter_model']=args.encounter
if args.route:settings['room_model']=args.route
print(freeze_bundle({'args':{**settings,'roles':[role]}},args.dest))
